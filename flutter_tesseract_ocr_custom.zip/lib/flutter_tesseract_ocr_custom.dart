import 'dart:async';
import 'package:flutter/services.dart';

class FlutterTesseractOcrCustom {
  static const MethodChannel _channel = MethodChannel('flutter_tesseract_ocr_custom');

  static Future<String?> extractText(String imagePath, {String language = 'eng'}) async {
    return await _channel.invokeMethod('extractText', {
      'imagePath': imagePath,
      'language': language,
    });
  }
}